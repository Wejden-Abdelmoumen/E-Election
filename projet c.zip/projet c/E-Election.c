#include<stdlib.h>
#include<stdio.h>
#include<string.h>




// repr�sentation d'un administrateur
struct Admin{
	int cin;
    char nom[20];
    char prenom[20];
    char position[50];
};


//D�finition de la structure liste des admins
typedef struct Noeud1 Noeud1;
struct Noeud1
{	
    struct Admin val;
    struct Noeud1 *suiv;
};
typedef Noeud1* Admins;
// fonction pour mettre a jours les informations d'un admin
void MiseAJourAdmin(struct Admin* A){
	char ch[50];
	printf("Nouvelle position:\n");
	fgets(ch,50,stdin);
	strcpy(A->position,ch);
}

// recherche d'un admin
Admins rechercher_Admin(Admins LA, int cin ){
	Admins aux = LA;
	while(aux != NULL){
		if (aux->val.cin == cin){
			break;
		}
		aux=aux->suiv;
	}
	return aux;
}

// importation des informations admins
int importer_admins(Admins *L, FILE*F ){

	if((F=fopen("Admins.txt","r"))==NULL){
		return (-1);
	}else{
		struct Admin A;
		*L=NULL;
		while (!(feof(F))){
			
			fscanf(F,"%d %s %s %s",&A.cin,&A.nom,&A.prenom,&A.position);
			Admins p;
            p = malloc(sizeof(Noeud1));
            p->suiv=*L;
            p->val=A;
            *L=p; 	
			
		}
		fclose(F);
		return 0;
		
	}
}

// la fonction ajout_Admin
Admins ajout_Admin(Admins L, struct Admin A){
	Admins p;
    p = malloc(sizeof(Noeud1));
    p->suiv=L;
    p->val=A;
    L=p;
    return L;
}


// repr�sentation d'un candidat
struct Candidat {
    int cin;
    char nom[20];
    char prenom[20];
    char groupe[10];
    char niveau[20];
    char description[300];
    int votes;
};

// afficher les details d'un candidat
void afficherCandidat(struct Candidat candidat){
    printf("CIN: %d\nPr�nom: %s\nNom: %s\nGroupe: %s\nNiveau: %s\nDescription: %s\nVotes: %d\n",candidat.cin, candidat.prenom, candidat.nom, candidat.groupe, candidat.niveau, candidat.description, candidat.votes);
	printf("--------------\n");	
}

//D�finition de la structure liste des candidats
typedef struct Noeud2 Noeud2;
struct Noeud2
{	
    struct Candidat val;
    struct Noeud2 *suiv;
};
typedef Noeud2* Candidats;

// fonction pour mettre a jours les informations d'un candidat
void MiseAJourCandidat(struct Candidat* C){
	char ch[10],niv[20],des[300];
	printf("Nouveau groupe:\nNouveau niveau:\nnouvelle description:\n");
	fgets(ch,50,stdin);
	strcpy(C->groupe,ch);
	fgets(niv,20,stdin);
	strcpy(C->niveau,niv);
	fgets(des,300,stdin);
	strcpy(C->description,des);
}


// recherche d'un candidat
Candidats rechercher_candidat(Candidats L, int cin ){
	Candidats aux = L;
	while(aux != NULL){
		if (aux->val.cin == cin){
			break;
		}
		aux=aux->suiv;
	}
	return aux;
}

// importation des informations candidats
int importer_candidats(Candidats *L, FILE*F ){

	if((F=fopen("Candidats.txt","r"))==NULL){
		return (-1);
	}else{
		struct Candidat C;
		*L=NULL;
		while (!(feof(F))){
			
			fscanf(F,"%d %s %s %s %s %s %d",&C.cin,&C.nom,&C.prenom,&C.groupe,&C.niveau,&C.description,&C.votes);
			Candidats p;
            p = malloc(sizeof(Noeud2));
            p->suiv=*L;
            p->val=C;
            *L=p; 	
			
		}
		fclose(F);
		return 0;
		
	}
}

// la fonction ajout_Candidat
Candidats ajout_Candidat(Candidats L, struct Candidat C){
	Candidats p;
    p = malloc(sizeof(Noeud2));
    p->suiv=L;
    p->val=C;
    L=p;
    return L;
}


// repr�sentation d'un simple utilisateur
struct simple_utilisateur{
    int cin;
    char nom[20];
    char prenom[20];
    char groupe[10];
    char niveau[20];	
};

//D�finition de la structure liste des simples utilisateurs
typedef struct Noeud3 Noeud3;
struct Noeud3
{	
    struct simple_utilisateur val;
    struct Noeud3 *suiv;
};
typedef Noeud3* S_U;

// importation des informations simple utilisateurs
int importer_su(S_U *L, FILE*F ){

	if((F=fopen("simple utilisateurs.txt","r"))==NULL){
		return (-1);
	}else{
		struct simple_utilisateur SU;
		*L=NULL;
		while (!(feof(F))){
			
			fscanf(F,"%d %s %s %s %s",&SU.cin,&SU.nom,&SU.prenom,&SU.groupe,&SU.niveau);
			S_U p;
            p = malloc(sizeof(Noeud3));
            p->suiv=*L;
            p->val=SU;
            *L=p; 	
			
		}
		fclose(F);
		return 0;
		
	}
}

// la fonction ajout d'un simple utilisateur
S_U ajout_S_U(S_U L, struct simple_utilisateur SU){
	S_U p;
    p = malloc(sizeof(Noeud3));
    p->suiv=L;
    p->val=SU;
    L=p;
    return L;
}


// repr�sentation d'un utilisateur
struct utilisateur{
	int id;
	char type[15];// admin ou candidat ou simple utilisateur
	char username[50];
	char password[30];
};

//D�finition de la structure liste de tous les utilisateurs
typedef struct Noeud4 Noeud4;
struct Noeud4
{	
    struct utilisateur val;
    struct Noeud4* suiv;
};
typedef Noeud4* Utilisateurs;

// la fonction ajout d'un utilisateur
Utilisateurs ajout_Utilisateur(Utilisateurs L, struct utilisateur U){
	Utilisateurs p;
    p = malloc(sizeof(Noeud4));
    p->suiv=L;
    p->val=U;
    L=p;
    return L;
}

// d�finition de la structure liste de tous les id (num�ros cin)
typedef struct Noeud Noeud;
struct Noeud
{	
    int val;
    struct Noeud *suiv;
};
typedef Noeud* idusers;

// la fonction ajout id
idusers ajout_iduser(idusers L, int cin){
	idusers p;
    p = malloc(sizeof(Noeud));
    p->suiv=L;
    p->val=cin;
    L=p;
    return L;
}

// repr�sentation d'une �lection
struct Election {
	int id;
    int annee;
    char titre[50];
    struct Candidat* candidats; 
    int nombreCandidats;
};

//D�finition de la structure liste de toutes les elections
typedef struct Noeud5 Noeud5;
struct Noeud5
{	
    struct Election val;
    struct Noeud5* suiv;
};
typedef Noeud5* Elections;

// la fonction ajout d'une election
Elections ajout_Election(Elections L, struct Election E){
	Elections p;
    p = malloc(sizeof(Noeud5));
    p->suiv=L;
    p->val=E;
    L=p;
    return L;
}

// afficher les d�tails d'une �lection
void afficherElection(struct Election election) {
    printf("ID: %d\nTitre: %s\nAnn�e: %d\n", election.id, election.titre, election.annee);
    printf("Candidats:\n");
    int i;
    for ( i = 0; i < election.nombreCandidats; i++) {
        afficherCandidat(election.candidats[i]);
        printf("--------------\n");
    }
}


// creation d'une �lection
struct Election creerElection() {
    struct Election nouvelleElection;

    printf("Titre de l'�lection: ");
    scanf("%s", nouvelleElection.titre);

    printf("Ann�e de l'�lection: ");
    scanf("%d", &nouvelleElection.annee);

    nouvelleElection.nombreCandidats = 0;
    nouvelleElection.candidats = NULL;

    return nouvelleElection;
}



// ajouter un candidat � une election
void ajouterCandidat(struct Election *E, struct Candidat C){
	
	E->nombreCandidats++;
	E->candidats = realloc(E->candidats,E->nombreCandidats * sizeof(struct Candidat));
	E->candidats[E->nombreCandidats-1]= C;
}
	












// recherche d'un utilisateur
Noeud* rechercher_utilisateur(Noeud* L, int cin ){
	Noeud* aux = L;
	while(aux != NULL){
		if (aux->val== cin){
			break;
		}
		aux=aux->suiv;
	}
	return aux;
}


	

//cr�ation d'un nouveau compte 

int creer_compte(int type,idusers L,Utilisateurs LU, Admins LA,Candidats LC,S_U LSU)
{
	struct utilisateur U;
	struct Admin A;
	struct Candidat C;
	struct simple_utilisateur SU;
    int cin;
	printf("Numero CIN:\n");
	scanf("%d",&cin);
	if (rechercher_utilisateur(L,cin) != NULL){
		printf("ce compte existe deja \nconnectez-vous\n");
		return 0;
	}else{
		
		U.id = cin;
		switch (type){
			case 1:
				
				A.cin = cin;
				printf("Nom:\n");
				scanf("%s",&A.nom);
				printf("Prenom:\n");
				scanf("%s",&A.prenom);	
				printf("Position:\n");
				scanf("%s",&A.position);
				ajout_Admin(LA,A);
				strcpy(U.type ,"administrateur");
				break;			
			case 2:
				
				C.cin = cin;
				printf("Nom:\n");
				scanf("%s",&C.nom);
				printf("Prenom:\n");
				scanf("%s",&C.prenom);	
				printf("Groupe:\n");
				scanf("%s",&C.groupe);
				printf("Niveau d'etudes:\n");
				scanf("%s",&C.niveau);
				C.votes = 0;// le nombre de votes est initialis� � 0
				char ch[400];
				strcpy(ch,"");
				while (strcmp(ch, "") == 0){
					printf("Donnez une breve description de vous-meme:\n");
					fgets(ch,400,stdin);
					if(strlen(ch)>300){
						printf("veuillez reduire votre description\n");
						strcpy(ch,"");
					}
				}
				strcpy(C.description , ch);
				ajout_Candidat(LC, C);
				strcpy(U.type,"Candidat");
				break;
			case 3:
				
				printf("Nom:\n");
				scanf("%s",&SU.nom);
				printf("Prenom:\n");
				scanf("%s",&SU.prenom);	
				printf("Groupe:\n");
				scanf("%s",&SU.groupe);
				printf("Niveau d'etudes:\n");
				scanf("%s",&SU.niveau);
				ajout_S_U(LSU,SU);
				strcpy(U.type , "simple utilisateur");
							
		}
		printf("Nom d'utilisateur:\n");
		scanf("%s",&U.username);
		printf("Mot de passe:\n");
		scanf("%s",&U.password);
		ajout_Utilisateur(LU,U);
		ajout_iduser(L,cin);
		
		printf("votre compte a ete cree avec succes\n");
		return 1;
	}
}

// connecxion � un compte 
int connect(idusers L,Utilisateurs LU){
	int cin;
	int c;
	printf("Numero CIN:\n");
	scanf("%d",&cin);
	if (rechercher_utilisateur(L,cin) == NULL){
		printf("Ce compte n'existe pas \nCreez un compte\n");
		
	    c= 0;	
	}else{
		
		printf("Nom d'utilisateur:\n");
		printf("Mot de passe:\n");
		c= 1;
	}
	return c;
}

int main(){
	FILE* F;
	idusers L=NULL;// liste cin
	Utilisateurs LU=NULL;// tous les utilisateurs
	Admins LA=NULL;// liste admins
	importer_admins(&LA,F);
	Candidats LC=NULL;// liste candidats
	importer_candidats(&LC,F);
	S_U LSU=NULL;// liste simple utilisateurs
	importer_su(&LSU,F);
	Elections LE=NULL; // liste elections
	int choix,test,cin,choix1;
	test=0;
	printf("1:Se connecter\n2:Creer un nouveau compte\n");
	scanf("%d",&choix1);
	if (choix1 == 1){

		test=connect(L,LU);
		if(test==0){
		    choix=0;
		
		    while(choix==0 || choix>3){
		
     	        printf("choisissez le type de compte a creer \n1:administrateur\n2:candidat\n3:simple utilisateur\n");
    	        scanf("%d",&choix);
                if(choix==0 || choix>3){
            	    printf("Erreur de saisie!\n Reessayez");
			    }
	        }
			creer_compte(choix,L,LU,LA,LC,LSU);			
		}
	}
	else{
		choix=0;
		
		while(choix==0 || choix>3){
		
     	    printf("choisissez le type de compte � cr�er 1:administrateur\n2:candidat\n3:simple utilisateur\n");
    	    scanf("%d",&choix);
            if(choix==0 || choix>3){
            	printf("Erreur de saisie!\n Reessayez\n");
			}
	    }
	    

	    test=creer_compte(choix,L,LU,LA,LC,LSU);
	    if(test==0){
	    	connect(L,LU);
		}	
	}
	int T=10;
	switch(choix){
		case 1:
			while(T!=0){
			    printf("1: Mettre a jour mon compte\n2: Creer une election\n3:Ajouter un candidats\n0:deconnexion\n");
				scanf("%d",&T);	
				if (T==1){
					printf("reecrivez votre numero CIN:\n");
					scanf("%d",cin);
					struct Admin * A=&rechercher_Admin(LA,cin)->val;
						
					MiseAJourAdmin(A);
				}
				if (T==2){
					struct Election newEl;
					newEl=creerElection();
					ajout_Election(LE,newEl);
				}
				if (T==3){
					struct Election * E=&LE->val;
					ajouterCandidat(E,LC->val);
					printf("Le candidat ayant le numero CIN: %d a ete ajoute a l'election avec succes\n ",LC->val.cin);	
				}
					
			}break;
        case 2:
        	while(T!=0){
        		printf("1:mettre a jour mon compte\n0:deconnexion\n");
        		scanf("%d",&T);
        		if (T==1){
					printf("reecrivez votre numero CIN:\n");
					scanf("%d",cin);
					struct Candidat * C=&rechercher_candidat(LC,cin)->val;
						
					MiseAJourCandidat(C);        			
				}
			
			}break;
		case 3:
			while(T!=0){
				printf("1:afficher la liste des candidats\n2:Voter\n0: deconnexion\n");
				scanf("%d",&T);
				if (T==1){
					Candidats p=LC;
					printf("--------------\n");
					while(p!=NULL){
						
						afficherCandidat(p->val);
						p=p->suiv;
					}
					
				}if (T==2){
					printf("donner le numero CIN du candidat que vous avez choisi\n");
					scanf("%d",&cin);
					Candidats C=rechercher_candidat(LC,cin);
					C->val.votes++;
				}
			}
	}
	printf("________\nLa Liste des votes:\n________\n");
	Candidats p=LC;
	while(p!=NULL){
		printf("\n Le candidat %s %s a obtenu %d votes\n",p->val.nom,p->val.prenom,p->val.votes);
		p=p->suiv;
	}
	
	
return 0;
}
